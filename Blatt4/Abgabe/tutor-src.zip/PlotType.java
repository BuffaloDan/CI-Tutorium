
public enum PlotType {
	LINE, DOT, SQUARE, CROSS;
}
