
public enum NeuronType {
	INPUT, OUTPUT, HIDDEN;
}
