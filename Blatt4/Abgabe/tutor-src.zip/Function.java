
public interface Function {
	
	public double calculate(double input);
	
}
