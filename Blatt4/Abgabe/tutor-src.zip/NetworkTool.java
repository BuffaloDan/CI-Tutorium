
import java.awt.Color;


public interface NetworkTool {

	public void run(int runs, Color plotColor);

	public Network getNetwork();
	
	public void screenShot();
	
	public void start();

}
