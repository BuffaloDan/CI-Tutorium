
public enum PropagationMode {
	ALL, OUTPUT;
}
